// Simple Hello World
 
#include <iostream>

using namespace std;



int main()
{
  cout << "Tarea Laboratorio 04" << endl;
  cout << "Ingrese la cantidad de números: " << endl;
  int n;
  cin >> n;
  int array [n];
  cout << "Ingrese los valores: " << endl;
  for (int i=0; i< n; i++){
      cin >> array[i];
      cout << "Valor Ingresado: " << array[i] << endl;
  }
  
  int suma =0;
  for (int j=0; j < n ; j++){
     
     suma += array[j];
     
  }
  cout << "Suma: " << suma << endl;
  
  int sumpar=0;
  int sumimpar=0;
  for (int k=0; k < n; k++){
      if (array[k] % 2 == 0){
          sumpar += array[k];
          } else{
          sumimpar += array[k];
          }     
  }
  
  cout << "Suma de posiciones pares: " << sumpar << endl;
  cout << "Suma de posiciones impares: " << sumimpar << endl;
  cout << "Orden Asendente: " << endl;
 for (int l = 1; l <= n - 1; l++) {
       for (int m = 1; m <= n - 1; m++) {
            if (array[m] > array[m + 1]) {
                int aux=0;
                aux = array[m];
            array[m] = array[m + 1];
            array[m + 1] = aux;
            }
        }
    }
  for (int o = 1; o <= n; o++) {
        cout << array[o] << " , " << endl;
    }
  
  
   
   cout << "Longitud: " << n << endl;
   
   
  return 0;
}